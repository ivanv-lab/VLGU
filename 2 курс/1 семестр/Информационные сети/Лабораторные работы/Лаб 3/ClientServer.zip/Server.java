import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {

    private static List<String> names=new ArrayList<>();

    public static void main(String[] args) {
        try{
            ServerSocket server=null;
            Socket client;

            server=new ServerSocket(1234);
            client=server.accept();

            System.out.println("Got client");
            PrintWriter out=null;
            BufferedReader in=null;

            in=new BufferedReader(new InputStreamReader(client.getInputStream()));
            out=new PrintWriter(client.getOutputStream(),true);

            String input;

            while ((input=in.readLine()) !=null){
                if(input.equalsIgnoreCase("exit")) break;
                if(isDigit(input)){
                    out.println(factorial(input));
                }
                else if(isString(input) && input.startsWith("getData")){
                    out.println(getData());
                }
                else if(isString(input)){
                    out.println(addData(input));
                }
            }
            out.close();
            in.close();
            client.close();
            System.out.println("Server closed");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    private static boolean isString(String input){
        if(!input.isEmpty()){
            return input.matches(".*[A-Za-z].*")
                   || input.matches(".*[0-9].*");
        }
        return false;
    }

    private static boolean isDigit(String input){
        if(!input.isEmpty())
            return input.matches("\\d+");

        return false;
    }

    private static String factorial(String input){
        try {
            int n = Integer.parseInt(input);
            long fact=1;
            for(int i=1;i<=n;i++){
                fact*=i;
            }
            return String.valueOf(fact);
        } catch (Exception e){
            return "Error";
        }
    }

    private static String addData(String input){
        try{
            if(input.startsWith("Name:")) {
                names.add(input.substring(input.indexOf("Name:")+5).trim());
                return "Data added";
            }
        } catch (Exception e){
            return "Error";
        }
        return "Server is connected. Input digits to get factorial. Input string, started with 'Name:' to add data. Input 'getData' to get data.";
    }

    private static String getData(){
        if(names.isEmpty()) return "Data is empty";

        StringBuilder out=new StringBuilder();
        for(String name:names){
            out.append(name+",");
        }
        out.delete(out.length()-1,out.length());
        return out.toString();
    }
}
