import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Утилиты управления сетью");

        while (true) {
            showMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    configureTCPIP();
                    break;
                case 2:
                    pingHost();
                    break;
                case 3:
                    traceRoute();
                    break;
                case 4:
                    showNetworkInfo();
                    break;
                case 5:
                    wiFiHotspot();
                    break;
                case 0:
                    System.out.println("Выход из программы...");
                    return;
                default:
                    System.out.println("Неверный выбор!");
            }
        }
    }

    private static void showMenu() {
        System.out.println("Главное меню");
        System.out.println("1. Настройка TCP/IP");
        System.out.println("2. Ping");
        System.out.println("3. Tracert");
        System.out.println("4. Информация о сети");
        System.out.println("5. Настройка Wi-Fi точки доступа");
        System.out.println("0. Выход");
        System.out.print("Выберите опцию: ");
    }

    private static int getUserChoice() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static void configureTCPIP() {
        System.out.println("Настройка TCP/IP");
        System.out.println("1. Показать текущую конфигурацию");
        System.out.println("2. Обновить IP адрес");
        System.out.println("3. Сбросить к DHCP");
        System.out.print("Выберите опцию: ");

        int choice = getUserChoice();

        try {
            Process process;
            switch (choice) {
                case 1: {
                    process = Runtime.getRuntime().exec("ipconfig");
                    printProcessOutput(process);
                    break;
                }
                case 2: {
                    setStaticIP();
                    break;
                }
                case 3: {
                    resetToDHCP();
                    break;
                }
                default:
                    System.out.println("Неверный выбор!");
            }
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void setStaticIP() {
        System.out.println("Введите IP адрес:");
        String ip = scanner.nextLine();
        System.out.println("Введите маску подсети:");
        String mask = scanner.nextLine();
        System.out.println("Введите шлюз по умолчанию:");
        String gateway = scanner.nextLine();

        try {
            String command = String.format("netsh interface ip set address \"Local Area Connection\" " +
                                           "static %s %s %s", ip, mask, gateway);
            Process process = Runtime.getRuntime().exec(command);
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void resetToDHCP() {
        try {
            Process process = Runtime.getRuntime().exec(
                    "netsh interface ip set address \"Local Area Connection\" dhcp"
            );
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void printProcessOutput(Process process) {
        try {
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), "866")); // Кодировка для Windows

            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            // Читаем ошибки
            BufferedReader errorReader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()));
            while ((line = errorReader.readLine()) != null) {
                System.out.println("Ошибка: " + line);
            }

            process.waitFor();

        } catch (IOException | InterruptedException e) {
            System.out.println("Ошибка чтения вывода: " + e.getMessage());
        }
    }

    private static void pingHost() {
        System.out.println("Ping утилита");
        System.out.println("Введите хост или IP адрес:");
        String host = scanner.nextLine();

        System.out.println("Кол-во пакетов (по умолчанию 4):");
        String count = scanner.nextLine();
        if (count.isEmpty()) count = "4";

        try {
            String command = String.format("ping -n %s %s", count, host);
            Process process = Runtime.getRuntime().exec(command);
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void traceRoute() {
        System.out.println("Tracert утилита");
        System.out.println("Введите хост или IP адрес:");
        String host = scanner.nextLine();

        try {
            String command = "tracert " + host;
            Process process = Runtime.getRuntime().exec(command);
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void showNetworkInfo() {
        System.out.println("Информация о сети");
        try {
            Process process = Runtime.getRuntime().exec("ipconfig /all");
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void wiFiHotspot() {
        System.out.println("Точка доступа Wi-Fi");
        System.out.println("1. Создать точку доступа");
        System.out.println("2. Запустить точку доступа");
        System.out.println("3. Остановить точку доступа");
        System.out.println("Выберите опцию:");

        int choice = getUserChoice();

        switch (choice) {
            case 1: {
                addHotspot();
                break;
            }
            case 2: {
                startHotspot();
                break;
            }
            case 3: {
                stopHotspot();
                break;
            }
            default:
                System.out.println("Неверный выбор!");
        }
    }

    private static void addHotspot() {
        System.out.println("Создание точки доступа Wi-Fi");
        System.out.println("Введите имя точки доступа:");
        String name = scanner.nextLine();
        System.out.println("Введите пароль точки доступа:");
        String password = scanner.nextLine();

        try {
            Process process = Runtime.getRuntime()
                    .exec(String.format("netsh wlan set hostednetwork mode=allow ssid=%s key=%s", name, password));
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void startHotspot() {
        System.out.println("Запуск созданной точки доступа");
        try {
            Process process = Runtime.getRuntime().exec("netsh wlan start hostednetwork");
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }

    private static void stopHotspot() {
        System.out.println("Остановка точки доступа");
        try {
            Process process = Runtime.getRuntime().exec("netsh wlan stop hostednetwork");
            printProcessOutput(process);
        } catch (IOException e) {
            System.out.println("Ошибка выполнения команды: " + e.getMessage());
        }
    }
}
