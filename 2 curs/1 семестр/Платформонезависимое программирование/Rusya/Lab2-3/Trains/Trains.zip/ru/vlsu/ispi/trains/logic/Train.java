package ru.vlsu.ispi.trains.logic;

public class Train {
    Carriage[] carriages;

    public Train(Carriage[] carriages) {
        this.carriages = carriages;
    }

    public Carriage[] getCarriages() {
        return carriages;
    }

    public void setCarriages(Carriage[] carriages) {
        this.carriages = carriages;
    }

    public int getNumberOfCarriages(){
        return carriages.length;
    }

    public int getTotalWeightOfCarriages(){
        int weight=0;
        for(Carriage carriage:carriages){
            weight+=carriage.getWeight();
        }

        return weight;
    }
}
