package ru.vlsu.ispi.shapes;

public class Point {
    int centerX;
    int centerY;

    public Point(int centerX, int centerY) {
        this.centerX = centerX;
        this.centerY = centerY;
    }

    public int getCenterX() {
        return centerX;
    }

    public void setCenterX(int centerX) {
        this.centerX = centerX;
    }

    public int getCenterY() {
        return centerY;
    }

    public void setCenterY(int centerY) {
        this.centerY = centerY;
    }

    public double distanceTo(Point other){
        int dx=this.centerX-other.centerX;
        int dy=this.centerY-other.centerY;
        return Math.sqrt(dx*dx+dy*dy);
    }
}
