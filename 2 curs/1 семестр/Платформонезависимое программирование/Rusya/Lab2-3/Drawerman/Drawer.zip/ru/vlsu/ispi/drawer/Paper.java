package ru.vlsu.ispi.drawer;

import ru.vlsu.ispi.shapes.Circle;
import ru.vlsu.ispi.shapes.Point;

public class Paper {
    private Circle drawedCircle;

    public void drawCircle(Circle circle){
        this.drawedCircle=circle;
    }

    public void fullFillAt(Point point){
        if(drawedCircle!=null && drawedCircle.contains(point)){
            drawedCircle.setPainted(true);
        }
    }
}
