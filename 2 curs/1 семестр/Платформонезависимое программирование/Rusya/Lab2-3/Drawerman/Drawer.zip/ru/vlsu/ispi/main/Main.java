package ru.vlsu.ispi.main;

import java.util.Scanner;

import ru.vlsu.ispi.shapes.Circle;
import ru.vlsu.ispi.drawer.Paper;
import ru.vlsu.ispi.shapes.Point;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int centerX = in.nextInt();
        int centerY = in.nextInt();
        int radius = in.nextInt();
        int penX = in.nextInt();
        int penY = in.nextInt();
        in.close();

        Point center = new Point(centerX, centerY);
        Circle circle = new Circle(center, radius);
        Point pen = new Point(penX, penY);

        Paper paper = new Paper();
        paper.drawCircle(circle);
        paper.fullFillAt(pen);

        if (circle.isPainted()) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}
