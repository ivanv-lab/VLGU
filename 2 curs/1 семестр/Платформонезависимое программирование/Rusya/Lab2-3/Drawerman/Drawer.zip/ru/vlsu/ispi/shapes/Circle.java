package ru.vlsu.ispi.shapes;

public class Circle {
    private Point center;
    private int radius;
    private boolean painted;

    public Circle(Point center, int radius) {
        this.center = center;
        this.radius = radius;
        this.painted=false;
    }

    public Point getCenter() {
        return center;
    }

    public int getRadius() {
        return radius;
    }

    public boolean isPainted(){
        return painted;
    }

    public void setPainted(boolean painted) {
        this.painted = painted;
    }

    public boolean contains(Point point){
        return center.distanceTo(point)<=radius;
    }
}
