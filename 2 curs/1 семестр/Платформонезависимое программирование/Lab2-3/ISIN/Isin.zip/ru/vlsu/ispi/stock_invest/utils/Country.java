package ru.vlsu.ispi.stock_invest.utils;

public class Country {
    private String code;
    private String name;

    public Country(String code){
        this.code=normalizeCode(code);
        this.name=this.code;
    }

    public Country(String code, String name) {
        this.code =normalizeCode(code);
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = normalizeCode(code);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String normalizeCode(String code){
        if(code==null)
            return "XX";

        if(code.length()>2)
            code=code.substring(0,2);

        if(code.length()<2)
            code=String.format("%-2s",code).replace(' ','X');

        StringBuilder builder=new StringBuilder();
        for(char c:code.toCharArray()){
            if(Character.isLetter(c)){
                builder.append(Character.toUpperCase(c));
            } else builder.append('X');
        }

        return builder.toString();
    }
}
