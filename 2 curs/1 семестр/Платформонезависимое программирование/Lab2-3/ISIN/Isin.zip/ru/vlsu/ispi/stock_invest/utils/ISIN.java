package ru.vlsu.ispi.stock_invest.utils;

public class ISIN {
    private Country country;
    private String nationalNumber;
    private byte checkCode;
    private boolean isValid;
    
    public ISIN(String isin) {
        this.isValid = validateIsin(isin);
    }

    public ISIN(String country, String nationalNumber, int checkCode) {
        this(country, nationalNumber, (byte) checkCode);
    }

    public ISIN(String country, String nationalNumber, byte checkCode) {
        this.country = new Country(country);
        this.nationalNumber = nationalNumber;
        this.checkCode = checkCode;
        this.isValid = validateComponents();
    }

    public ISIN(String country, String nationalNumber, String checkCode) {
        this.country = new Country(country);
        this.nationalNumber = nationalNumber;
        this.isValid = validateIsin(checkCode);
    }

    public ISIN(String country, String nationalNumber) {
        this.country = new Country(country);
        this.nationalNumber = nationalNumber;
        this.isValid = validateComponents();
        if (this.isValid) {
            this.checkCode = calculateCheckCode();
        }
    }
    
    public ISIN(Country country, String nationalNumber, int checkCode) {
        this(country, nationalNumber, (byte) checkCode);
    }

    public ISIN(Country country, String nationalNumber, byte checkCode) {
        this.country = country;
        this.nationalNumber = nationalNumber;
        this.checkCode = checkCode;
        this.isValid = validateComponents();
    }

    public ISIN(Country country, String nationalNumber, String checkCode) {
        this.country = country;
        this.nationalNumber = nationalNumber;
        this.isValid = validateIsin(checkCode);
    }

    public ISIN(Country country, String nationalNumber) {
        this.country = country;
        this.nationalNumber = nationalNumber;
        this.isValid = validateComponents();
        if (this.isValid) {
            this.checkCode = calculateCheckCode();
        }
    }

    public boolean isValid(){
        return isValid;
    }

    public Country getCountry(){
        return country;
    }

    public String getNationalNumber(){
        return nationalNumber;
    }

    public int getCheckCodeInt(){
        return checkCode;
    }

    public byte getCheckCodeByte(){
        return checkCode;
    }

    public String getCheckCodeString(){
        return String.valueOf(checkCode);
    }
    
    private boolean validateIsin(String isin){
        if(isin==null || isin.length()!=12)
            return false;

        String countryCode=isin.substring(0,2);
        String nationalNum=isin.substring(2,11);
        String checkChar=isin.substring(11,12);

        this.country=new Country(countryCode);
        this.nationalNumber=nationalNum;

        return validateCheckCode(checkChar);
    }

    private boolean validateCheckCode(String checkCodeStr){
        try{
            this.checkCode=Byte.parseByte(checkCodeStr);
            return validateComponents();
        } catch (NumberFormatException e){
            return false;
        }
    }

    private boolean validateComponents(){
        if(country==null || country.getCode()==null
        || !country.getCode().matches("[A-Z]{2}]"))
            return false;

        if(nationalNumber==null||nationalNumber.length()!=9
        || !nationalNumber.matches("[A-Z0-9]{9}"))
            return false;

        if(checkCode<0 || checkCode>9)
            return false;

        return validateLun();
    }

    private boolean validateLun(){
        String prepared=prepareLun();
        int lunResult=calcLun(prepared);
        return lunResult==0;
    }

    private byte calculateCheckCode(){
        String tempIsin=country.getCode()+nationalNumber+"0";
        String prepared=prepareLun(tempIsin);
        int lunResult=calcLun(prepared);

        if(lunResult==0)
            return 0;
        else return (byte) (10-lunResult);
    }

    private String prepareLun(){
        return prepareLun(country.getCode()+nationalNumber+checkCode);
    }

    private String prepareLun(String isin){
        StringBuilder builder=new StringBuilder();

        for(char c: isin.toCharArray()){
            if(Character.isDigit(c))
                builder.append(c);
            else if(Character.isLetter(c)){
                int num=Character.toUpperCase(c)-'A'+10;
                builder.append(num);
            }
        }

        return builder.toString();
    }

    private int calcLun(String number){
        int sum = 0;
        boolean isEvenPosition = false;

        for (int i = number.length() - 1; i >= 0; i--) {
            int digit = Character.getNumericValue(number.charAt(i));

            if (isEvenPosition) {
                digit *= 2;
                if (digit > 9) {
                    digit = digit / 10 + digit % 10;
                }
            }

            sum += digit;
            isEvenPosition = !isEvenPosition;
        }

        return sum % 10;
    }
}
